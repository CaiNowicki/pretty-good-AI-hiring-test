import io
import os
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path
from unittest.mock import patch

from voicebot.cli import main


class CliTests(unittest.TestCase):
    def test_dev_run_can_delete_scaffold_after_demo_prompt(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            calls_root = Path(temp_dir) / "calls"
            output = io.StringIO()

            with patch("builtins.input", side_effect=["DEV", "DELETE"]):
                with redirect_stdout(output):
                    result = main(
                        [
                            "a01_specific_time",
                            "dev",
                            "--calls-root",
                            str(calls_root),
                        ]
                    )

            self.assertEqual(result, 0)
            call_dir = calls_root / "appointment_scheduling" / "call-001"
            self.assertFalse(call_dir.exists())
            self.assertIn("DEV CLEANUP", output.getvalue())
            self.assertIn("Deleted dev artifacts", output.getvalue())

    def test_dev_run_keeps_scaffold_when_cleanup_is_not_confirmed(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            calls_root = Path(temp_dir) / "calls"
            output = io.StringIO()

            with patch("builtins.input", side_effect=["DEV", ""]):
                with redirect_stdout(output):
                    result = main(
                        [
                            "a01_specific_time",
                            "dev",
                            "--calls-root",
                            str(calls_root),
                        ]
                    )

            self.assertEqual(result, 0)
            call_dir = calls_root / "appointment_scheduling" / "call-001"
            self.assertTrue(call_dir.exists())
            self.assertIn("Keeping dev artifacts", output.getvalue())

    def test_dry_run_accepts_public_base_url_override(self):
        output = io.StringIO()

        with tempfile.NamedTemporaryFile("w", delete=False, encoding="utf-8") as env_file:
            env_file.write("TWILIO_FROM_NUMBER=+15551234567\n")
            env_path = env_file.name

        try:
            with redirect_stdout(output):
                result = main(
                    [
                        "dry-run",
                        "--env-file",
                        env_path,
                        "--public-base-url",
                        "https://current-tunnel.example",
                    ]
                )
        finally:
            Path(env_path).unlink(missing_ok=True)

        self.assertEqual(result, 0)
        self.assertIn(
            "https://current-tunnel.example/twilio/voice?scenario_id=t01_smoke",
            output.getvalue(),
        )

    def test_server_public_base_url_override_sets_process_env(self):
        with patch.dict(os.environ, {}, clear=True):
            with patch("uvicorn.run") as run:
                result = main(
                    [
                        "server",
                        "--public-base-url",
                        "https://current-tunnel.example",
                    ]
                )

            self.assertEqual(result, 0)
            self.assertEqual(
                os.environ["PUBLIC_BASE_URL"],
                "https://current-tunnel.example",
            )
            run.assert_called_once()


if __name__ == "__main__":
    unittest.main()
